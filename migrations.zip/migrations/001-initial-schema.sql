--Up

CREATE TABLE Message(
    id INTEGER PRIMARY KEY,
    customer_name STRING,
    emailid STRING,
    balance FLOAT,
    city STRING
);



--Down


--Drop table Message;

